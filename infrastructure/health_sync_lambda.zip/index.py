"""
Lambda function to sync ECS task health status to Service Discovery instances.

This function:
1. Lists all running ECS tasks for the service
2. Checks their health status
3. Finds corresponding Service Discovery instances
4. Updates Service Discovery instance health status to match ECS task health
"""

import json
import os
import boto3
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients with explicit region
# Use Lambda's execution region (us-east-1)
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')
ecs = boto3.client('ecs', region_name=AWS_REGION)
servicediscovery = boto3.client('servicediscovery', region_name=AWS_REGION)

# Get environment variables
SERVICE_DISCOVERY_SERVICE_ID = os.environ['SERVICE_DISCOVERY_SERVICE_ID']
ECS_CLUSTER = os.environ['ECS_CLUSTER']
ECS_SERVICE = os.environ['ECS_SERVICE']


def handler(event, context):
    """
    Main Lambda handler
    """
    try:
        logger.info(f"Starting health sync for ECS service: {ECS_SERVICE}")
        
        # Get all running tasks for the ECS service
        tasks_response = ecs.list_tasks(
            cluster=ECS_CLUSTER,
            serviceName=ECS_SERVICE,
            desiredStatus='RUNNING'
        )
        
        task_arns = tasks_response.get('taskArns', [])
        
        if not task_arns:
            logger.warning("No running tasks found")
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'No running tasks'})
            }
        
        logger.info(f"Found {len(task_arns)} running task(s)")
        
        # Describe tasks to get health status
        tasks_details = ecs.describe_tasks(
            cluster=ECS_CLUSTER,
            tasks=task_arns
        )
        
        # Get Service Discovery instances
        instances_response = servicediscovery.list_instances(
            ServiceId=SERVICE_DISCOVERY_SERVICE_ID
        )
        
        instances = instances_response.get('Instances', [])
        logger.info(f"Found {len(instances)} Service Discovery instance(s)")
        
        # Create mapping of task ARN to task details
        task_map = {}
        for task in tasks_details.get('tasks', []):
            task_arn = task.get('taskArn', '')
            # Extract task ID from ARN (last segment after /)
            task_id = task_arn.split('/')[-1] if task_arn else ''
            task_map[task_id] = {
                'arn': task_arn,
                'health': task.get('healthStatus', 'UNKNOWN'),
                'status': task.get('lastStatus', 'UNKNOWN')
            }
        
        # Get actual health status for all instances (for custom health checks)
        # Note: For custom health checks, we need to explicitly update health status
        # The AWS_INIT_HEALTH_STATUS attribute is just metadata, not the actual health status
        instance_ids = [inst.get('Id', '') for inst in instances if inst.get('Id')]
        health_status_map = {}
        if instance_ids:
            try:
                # get_instances_health_status expects Instances as a dict mapping instance_id to empty dict
                health_status_response = servicediscovery.get_instances_health_status(
                    ServiceId=SERVICE_DISCOVERY_SERVICE_ID,
                    Instances={inst_id: {} for inst_id in instance_ids}
                )
                # The response format is: {'Status': {'instance_id': 'HEALTHY'|'UNHEALTHY'}}
                health_status_map = health_status_response.get('Status', {})
                logger.info(f"Retrieved health status for {len(health_status_map)} instance(s): {health_status_map}")
            except Exception as e:
                logger.warning(f"Could not retrieve health status (will use attribute fallback): {str(e)}")
                # Fall back to attribute-based check - assume UNKNOWN if we can't get status
                health_status_map = {inst_id: 'UNKNOWN' for inst_id in instance_ids}
        
        # Update Service Discovery instance health based on ECS task health
        updated_count = 0
        for instance in instances:
            instance_id = instance.get('Id', '')
            # For custom health checks, use the actual health status if available
            # Otherwise fall back to the attribute
            if instance_id in health_status_map:
                current_health = health_status_map[instance_id]
            else:
                current_health = instance.get('Attributes', {}).get('AWS_INIT_HEALTH_STATUS', 'UNKNOWN')
            
            # Find matching ECS task by instance ID (instance ID = task ID)
            if instance_id in task_map:
                task_info = task_map[instance_id]
                task_health = task_info['health']
                task_status = task_info['status']
                
                # Map ECS health to Service Discovery health
                # UNKNOWN + RUNNING should be treated as HEALTHY (tasks start as UNKNOWN until health checks pass)
                # Only mark as UNHEALTHY if explicitly unhealthy or not running
                if task_health == 'UNHEALTHY' or task_status != 'RUNNING':
                    target_health = 'UNHEALTHY'
                elif task_health == 'HEALTHY' or (task_health == 'UNKNOWN' and task_status == 'RUNNING'):
                    target_health = 'HEALTHY'
                else:
                    # Very conservative: if we can't determine, default to UNHEALTHY
                    target_health = 'UNHEALTHY'
            
                # Only update if health status needs to change
                if current_health != target_health:
                    try:
                        logger.info(f"Attempting to update instance {instance_id} from {current_health} to {target_health}")
                        logger.info(f"Using Service ID: {SERVICE_DISCOVERY_SERVICE_ID}, Region: {AWS_REGION}")
                        
                        response = servicediscovery.update_instance_custom_health_status(
                            ServiceId=SERVICE_DISCOVERY_SERVICE_ID,
                            InstanceId=instance_id,
                            Status=target_health
                        )
                        logger.info(f"Successfully updated instance {instance_id} from {current_health} to {target_health} (task health: {task_health}, status: {task_status})")
                        logger.info(f"API Response: {json.dumps(response)}")
                        updated_count += 1
                    except Exception as e:
                        logger.error(f"Failed to update instance {instance_id}: {str(e)}")
                        logger.error(f"Service ID used: {SERVICE_DISCOVERY_SERVICE_ID}")
                        logger.error(f"Instance ID used: {instance_id}")
                        logger.error(f"Region: {AWS_REGION}")
                        logger.error(f"Exception type: {type(e).__name__}")
                        import traceback
                        logger.error(f"Traceback: {traceback.format_exc()}")
                else:
                    logger.debug(f"Instance {instance_id} health already correct: {current_health}")
            else:
                # No matching ECS task found - mark instance as UNHEALTHY
                # This handles stale instances from stopped tasks
                logger.warning(f"No matching ECS task found for instance {instance_id} - marking as UNHEALTHY")
                if current_health != 'UNHEALTHY':
                    try:
                        logger.info(f"Marking orphaned instance {instance_id} as UNHEALTHY")
                        servicediscovery.update_instance_custom_health_status(
                            ServiceId=SERVICE_DISCOVERY_SERVICE_ID,
                            InstanceId=instance_id,
                            Status='UNHEALTHY'
                        )
                        logger.info(f"Successfully marked instance {instance_id} as UNHEALTHY")
                        updated_count += 1
                    except Exception as e:
                        logger.error(f"Failed to mark orphaned instance {instance_id} as UNHEALTHY: {str(e)}")
        
        result = {
            'statusCode': 200,
            'message': f'Health sync completed. Updated {updated_count} instance(s)',
            'tasks_checked': len(task_arns),
            'instances_checked': len(instances),
            'instances_updated': updated_count
        }
        
        logger.info(json.dumps(result))
        return result
        
    except Exception as e:
        logger.error(f"Error in health sync: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

